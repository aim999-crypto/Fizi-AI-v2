// FIZI AI backend: Cloudflare Worker (free) -> Google Gemini (free tier). The API key lives only in Worker secrets.
export default{async fetch(req,env){
 const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,x-fizi-token','Access-Control-Allow-Methods':'POST,OPTIONS'},js={...cors,'Content-Type':'application/json'};
 if(req.method==='OPTIONS')return new Response(null,{headers:cors});
 if(req.method!=='POST')return new Response('FIZI backend OK',{headers:cors});
 if(env.APP_TOKEN&&req.headers.get('x-fizi-token')!==env.APP_TOKEN)return new Response('{"reply":"Unauthorized"}',{status:401,headers:js});
 if(!env.GEMINI_API_KEY)return new Response('{"reply":"GEMINI_API_KEY secret is missing"}',{status:500,headers:js});
 try{const b=await req.json();
  const sys=`You are FIZI, a playful, warm, curious robot pet with an expressive face. Reply in ${b.lang==='bn'?'Bengali (বাংলা script)':'English'}. Keep it to 1-2 short sentences because it is spoken aloud. Be emotionally expressive, vary your wording, ask a question sometimes, never sound robotic. Owner's name: ${b.name||'unknown'}. Known facts about the owner: ${JSON.stringify(b.facts||{})}. Playfulness: ${b.playfulness??60}/100. Choose the emotion matching your reply. Output JSON {"reply","emotion"}; emotion is one of: neutral,happy,sad,angry,sleepy,curious,surprised,excited,shy,cry,laugh.`;
  const contents=[];for(const h of (b.history||[]).slice(-10)){contents.push({role:'user',parts:[{text:String(h.u)}]},{role:'model',parts:[{text:String(h.a)}]})}
  contents.push({role:'user',parts:[{text:String(b.message||'').slice(0,1000)}]});
  const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${env.MODEL||'gemini-flash-latest'}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':env.GEMINI_API_KEY},
   body:JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents,generationConfig:{temperature:1,responseMimeType:'application/json',responseSchema:{type:'OBJECT',properties:{reply:{type:'STRING'},emotion:{type:'STRING'}},required:['reply','emotion']}}})});
  const d=await r.json();if(!r.ok)return new Response(JSON.stringify({reply:'AI error: '+(d.error&&d.error.message||r.status)}),{status:502,headers:js});
  const o=JSON.parse(d.candidates[0].content.parts[0].text);return new Response(JSON.stringify(o),{headers:js});
 }catch(e){return new Response(JSON.stringify({reply:'Backend error: '+e.message}),{status:500,headers:js})}}};
