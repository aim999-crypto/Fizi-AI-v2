// All on-device. Face recognition: face-api.js (bundled at build time). Falls back to motion tracking if models are missing.
const Vision={on:false,mode:'none',ready:false,tried:false,faces:{},pending:null,seenAt:0,prev:null,
 async loadFaces(){const a=await Mem.all();this.faces={};for(const k in a)if(k.startsWith('face:'))this.faces[k.slice(5)]=new Float32Array(a[k])},
 async init(){if(!window.faceapi)return;try{const u='vendor/model';await faceapi.nets.tinyFaceDetector.loadFromUri(u);await faceapi.nets.faceLandmark68TinyNet.loadFromUri(u);await faceapi.nets.faceRecognitionNet.loadFromUri(u);this.ready=true}catch(e){this.err=e.message}},
 async start(video,cb){try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:320},height:{ideal:240}},audio:false});video.srcObject=s;await video.play();this.s=s;this.v=video;this.cb=cb;this.on=true;
  await this.loadFaces();if(!this.tried){this.tried=true;await this.init()}this.mode=this.ready?'recog':'motion';
  this.c=document.createElement('canvas');this.c.width=32;this.c.height=24;this.x=this.c.getContext('2d',{willReadFrequently:true});this.tick();return true}catch(e){return false}},
 stop(){this.on=false;this.s&&this.s.getTracks().forEach(t=>t.stop())},
 match(d){let b=null,bd=.55;for(const n in this.faces){const x=faceapi.euclideanDistance(d,this.faces[n]);if(x<bd){bd=x;b=n}}return b},
 async enroll(name){if(!this.pending)return false;this.faces[name]=this.pending;await Mem.set('face:'+name,Array.from(this.pending));return true},
 async tick(){if(!this.on)return;let p=null,name=null;
  try{if(this.mode=='recog'){const r=await faceapi.detectSingleFace(this.v,new faceapi.TinyFaceDetectorOptions({inputSize:224,scoreThreshold:.5})).withFaceLandmarks(true).withFaceDescriptor();
    if(r){const b=r.detection.box;p=[1-2*(b.x+b.width/2)/this.v.videoWidth,2*(b.y+b.height/2)/this.v.videoHeight-1];name=this.match(r.descriptor);this.pending=r.descriptor}else this.pending=null}
   else{this.x.drawImage(this.v,0,0,32,24);const d=this.x.getImageData(0,0,32,24).data,g=[];let sx=0,sy=0,n=0;for(let i=0;i<768;i++)g[i]=d[i*4]*.3+d[i*4+1]*.6+d[i*4+2]*.1;
    if(this.prev)for(let i=0;i<768;i++)if(Math.abs(g[i]-this.prev[i])>28){sx+=i%32;sy+=(i/32|0);n++}this.prev=g;if(n>12)p=[1-2*(sx/n)/32,2*(sy/n)/24-1]}}catch(e){}
  if(p)this.seenAt=Date.now();this.cb(p,this.seenAt,name);setTimeout(()=>this.tick(),this.mode=='recog'?450:160)}};
