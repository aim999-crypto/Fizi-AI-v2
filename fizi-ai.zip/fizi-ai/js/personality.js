const P={last:Date.now(),
 R:{greet:{bn:['হ্যালো {n}! আজ কেমন আছো?','আরে {n}! তোমাকে দেখে ভালো লাগছে!','হাই {n}, কী খবর?'],en:['Hi {n}! How are you today?','Hey {n}! Good to see you!','Hello {n}, what\'s up?']},
 praise:{bn:['ধন্যবাদ! আমি খুব খুশি 😊','উফ, লজ্জা লাগছে!'],en:['Thank you! That makes me happy 😊','Aww, I\'m blushing!']},
 joke:{bn:['রোবট কেন ছুটিতে গেল? রিচার্জ করতে!','কম্পিউটার কেন ঠান্ডা লাগে? কারণ তার উইন্ডো খোলা!'],en:['Why did the robot go on vacation? To recharge!','Why was the computer cold? It left its Windows open!']},
 name:{bn:['তোমার নাম মনে রাখলাম: {v}!'],en:['I\'ll remember your name: {v}!']},
 sad:{bn:['আহা, মন খারাপ? আমি তোমার পাশেই আছি 🥺','কী হয়েছে বলো তো? আমি শুনছি।'],en:['Aww, feeling down? I\'m right here 🥺','Tell me what happened, I\'m listening.']},
 angry:{bn:['সরি… রাগ করো না, আমার মন খারাপ হয়ে গেল।','আমি কি কিছু ভুল করেছি?'],en:['Sorry… please don\'t be mad, I feel sad now.','Did I do something wrong?']},
 how:{bn:['আমি দারুণ আছি! তুমি কেমন আছো?','তোমার সাথে কথা বলে ভালো লাগছে!'],en:['I\'m great! How about you?','Talking to you makes me happy!']},
 who:{bn:['আমি FIZI, তোমার ছোট্ট রোবট বন্ধু!'],en:['I\'m FIZI, your little robot friend!']},
 unk:{bn:['হুম, এটা নতুন! আরেকটু বলবে?','মজার কথা! তুমি কী ভাবছো?','আমি এটা বুঝিনি। অন্যভাবে বলবে?'],en:['Hmm, that\'s new to me! Tell me more?','Interesting! What do you think?','I didn\'t get that. Can you rephrase?']}},
 pro:{idle:{bn:['এই, তুমি কি ব্যস্ত? একটু গল্প করবে?','জানো, আমার একটা মজার জোক মনে পড়েছে!','আজ তোমার দিন কেমন কাটছে?'],en:['Hey, are you busy? Want to chat?','I just thought of a funny joke!','How is your day going?']},
  greet:{bn:['আরে {n}! তোমাকে দেখে খুব ভালো লাগছে!'],en:['Hey {n}! So happy to see you!']},
  unknown:{bn:['আমি তোমাকে চিনি না। চাইলে বলো, আমার মুখ মনে রাখো, আমার নাম ...'],en:['I don\'t know you yet. Say: remember my face, my name is ...']}},
 songs:{bn:['লা লা লা, গান গাই, তোমার সাথে নাচতে চাই। তারা ঝিলমিল, মন খুশি খুশি, আমি ফিজি, তোমার বন্ধু।','আকাশে চাঁদ হাসে, ফিজি তোমার পাশে। গান গেয়ে নাচি আমি, তুমি আমার সবচেয়ে দামি।'],en:['La la la, sing along, FIZI hums a happy song. You and me, side by side, a robot friend who beams with pride.','Moon is smiling in the sky, FIZI waves and says hi. Dance with me, spin around, happiest friend I have found.']},
 pick(a){return a[Math.floor(Math.random()*a.length)]},
 async reply(text,lang,face){const t=text.toLowerCase(),n=(await Mem.get('name'))||(lang=='bn'?'বন্ধু':'friend');let k='unk',emo='curious',v='';
  const m=t.match(/(?:my name is|আমার নাম)\s*([^\s.!?]+)/);
  if(m){v=m[1];await Mem.set('name',v);k='name';emo='excited'}
  else if(/মন খারাপ|কষ্ট|কাঁদ|একা|sad|cry|lonely|hurt/.test(t)){k='sad';emo='sad'}
  else if(/রাগ|বোকা|বাজে|চুপ|angry|stupid|shut up|hate/.test(t)){k='angry';emo='cry'}
  else if(/কেমন আছ|কি খবর|কী খবর|how are you/.test(t)){k='how';emo='happy'}
  else if(/তোমার নাম|কে তুমি|who are you|your name/.test(t)){k='who';emo='excited'}
  else if(/hello|hi\b|hey|হ্যালো|হাই|সালাম/.test(t)){k='greet';emo='happy'}
  else if(/good|great|smart|love|ভালো|সুন্দর|দারুণ/.test(t)){k='praise';emo='shy'}
  else if(/joke|জোক|হাসাও|মজা/.test(t)){k='joke';emo='laugh'}
  face.set(emo);setTimeout(()=>face.set('neutral'),3500);this.last=Date.now();
  return this.pick(this.R[k][lang]).replace('{n}',n).replace('{v}',v)},
 async gem(text,lang,key){let err;for(const m of['gemini-flash-latest','gemini-2.5-flash','gemini-2.0-flash']){try{return await this.gem1(text,lang,key,m)}catch(e){err=e}}throw err},
 async gem1(text,lang,key,model){const h=(await Mem.get('hist'))||[],all=await Mem.all();['hist','api','tok','gkey','setup','lang','tts','camon','play','hf'].forEach(k=>delete all[k]);Object.keys(all).forEach(k=>k.startsWith('face:')&&delete all[k]);
  const sys=`You are FIZI, a playful, warm, curious robot pet with an expressive face. Reply in ${lang=='bn'?'Bengali (বাংলা script)':'English'}. Keep it to 1-2 short sentences because it is spoken aloud. Be emotionally expressive, vary wording, sometimes ask a question, never sound robotic. Owner's name: ${all.name||'unknown'}. Known facts: ${JSON.stringify(all)}. Output JSON {reply,emotion}; emotion is one of: neutral,happy,sad,angry,sleepy,curious,surprised,excited,shy,cry,laugh.`;
  const c=[];h.slice(-10).forEach(x=>c.push({role:'user',parts:[{text:String(x.u)}]},{role:'model',parts:[{text:String(x.a)}]}));c.push({role:'user',parts:[{text:text.slice(0,1000)}]});
  const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents:c,generationConfig:{temperature:1,responseMimeType:'application/json',responseSchema:{type:'OBJECT',properties:{reply:{type:'STRING'},emotion:{type:'STRING'}},required:['reply','emotion']}}})});
  const d=await r.json();if(!r.ok)throw new Error(d.error&&d.error.message||r.status);return JSON.parse(d.candidates[0].content.parts[0].text)},
 async ask(text,lang,face){const url=await Mem.get('api'),gk=await Mem.get('gkey');
  if(gk&&!url){try{const j=await this.gem(text,lang,gk),h=(await Mem.get('hist'))||[];h.push({u:text,a:j.reply});await Mem.set('hist',h.slice(-50));face.set(EMO[j.emotion]?j.emotion:'happy');setTimeout(()=>face.set('neutral'),3500);this.last=Date.now();return j.reply}
   catch(e){return (lang=='bn'?'(AI সমস্যা, অফলাইন মোড: ':'(AI problem, offline mode: ')+String(e.message).slice(0,80)+') '+await this.reply(text,lang,face)}}
  if(url){try{const h=(await Mem.get('hist'))||[],all=await Mem.all();['hist','api','tok','gkey','setup','lang','tts','camon','play','hf'].forEach(k=>delete all[k]);Object.keys(all).forEach(k=>k.startsWith('face:')&&delete all[k]);const tok=await Mem.get('tok');
   const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json',...(tok?{'x-fizi-token':tok}:{})},body:JSON.stringify({message:text,lang,history:h.slice(-10),name:all.name,facts:all,playfulness:60})});
   if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json();h.push({u:text,a:j.reply});await Mem.set('hist',h.slice(-50));
   face.set(EMO[j.emotion]?j.emotion:'happy');setTimeout(()=>face.set('neutral'),3500);this.last=Date.now();return j.reply}
  catch(e){return (lang=='bn'?'(AI ব্যাকএন্ডে সমস্যা, অফলাইন মোড: '+e.message+') ':'(AI backend problem, offline mode: '+e.message+') ')+await this.reply(text,lang,face)}}
  return this.reply(text,lang,face)}};
