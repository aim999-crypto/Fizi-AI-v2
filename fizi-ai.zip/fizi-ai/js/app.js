const $=s=>document.querySelector(s);let hf=true,busy=false,hfRun=false,nextPro=Date.now()+60000,lastWho=null,unk=0,unkAt=0,face,lang='bn',tts=false,camOn=true,seen=false,lastSeen=0;
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),3500)};
const add=(t,u)=>{const d=document.createElement('div');d.className='m'+(u?' u':'');d.textContent=t;$('#log').append(d);d.scrollIntoView()};
const tab=n=>{document.querySelectorAll('#sheet section').forEach(s=>s.classList.toggle('on',s.id==n));if(n=='memory')showMem()};
const sheet=o=>{$('#sheet').classList.toggle('on',o);if(o)tab('chat')};
async function showMem(){const a=await Mem.all();$('#mem').innerHTML='';for(const k in a){if(['hist','api','tok','gkey','setup','lang','tts','camon','hf'].includes(k))continue;const d=document.createElement('div');d.className='mi';d.textContent=k.startsWith('face:')?'👤 '+k.slice(5)+' (face data)':k+': '+a[k];const b=document.createElement('button');b.textContent='✕';b.onclick=async()=>{await Mem.del(k);showMem()};d.append(b);$('#mem').append(d)}}
const emo=(n,o,ms=3000)=>{face.set(n,o);clearTimeout(emo.t);emo.t=setTimeout(()=>face.set('neutral'),ms)};
const sleep=ms=>new Promise(r=>setTimeout(r,ms)),sheetOpen=()=>$('#sheet').classList.contains('on');
async function speakNow(t){busy=true;Voice.stopListen();try{await Voice.speak(t,lang,face)}finally{busy=false;P.last=Date.now()}}
function tune(){const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return()=>{};const ac=new AC(),n=[261.6,293.7,329.6,392,440,523.3,440,392],g=ac.createGain();g.gain.value=.07;g.connect(ac.destination);let i=0;const id=setInterval(()=>{const o=ac.createOscillator();o.type='triangle';o.frequency.value=n[i++%n.length];o.connect(g);o.start();o.stop(ac.currentTime+.3)},350);return()=>{clearInterval(id);ac.close()}}
async function sing(){busy=true;Voice.stopListen();let lyr;const gk=await Mem.get('gkey');
 if(gk){try{lyr=(await P.gem(lang=='bn'?'আমার জন্য একটা ছোট্ট মজার মৌলিক গান লেখো, ৪ লাইন':'Write a short original cheerful 4-line song for me',lang,gk)).reply}catch(e){}}
 if(!lyr)lyr=P.pick(P.songs[lang]);add(lyr);const stop=tune();face.set('happy');face.dance=true;
 try{await Voice.speak(lyr,lang,face,{pitch:1.5,rate:.8})}finally{stop();face.dance=false;face.set('neutral');busy=false;P.last=Date.now()}}
async function faceCmd(t){if(!/মুখ মনে রাখ|remember my face/i.test(t))return null;
 const nm=(t.match(/(?:নাম|name is|i am|i'm)\s*([^\s,.!?]+)/i)||[])[1]||await Mem.get('name');
 if(!nm)return lang=='bn'?'তোমার নাম বলো, যেমন: আমার মুখ মনে রাখো, আমার নাম রিয়া':'Tell me your name, e.g. remember my face, my name is Ria';
 if(!Vision.on||!Vision.pending)return lang=='bn'?'আগে ক্যামেরার সামনে এসো, তোমার মুখ দেখতে পাচ্ছি না।':'Come in front of the camera first, I can\'t see your face.';
 await Vision.enroll(nm);await Mem.set('name',nm);return lang=='bn'?'ঠিক আছে '+nm+', তোমার মুখ মনে রাখলাম! মেমরি থেকে যেকোনো সময় মুছতে পারো।':'Okay '+nm+', I will remember your face! You can delete it in Memory anytime.'}
async function say(text,speak){P.last=Date.now();add(text,1);
 if(/গান গাও|গান শোনাও|গান গা\b|\bsing\b/i.test(text)){await sing();return}
 let r=await faceCmd(text);if(!r)r=await P.ask(text,lang,face);add(r);if(tts||speak)await speakNow(r)}
async function proact(kind,hint){if(busy||sheetOpen())return;const gk=await Mem.get('gkey');let t;
 if(gk){try{t=(await P.gem('[Event: '+hint+'] Say one short natural thing to the owner.',lang,gk)).reply}catch(e){}}
 if(!t)t=P.pick((P.pro[kind]||P.pro.idle)[lang]).replace('{n}',(await Mem.get('name'))||'');
 add(t);face.set('happy');await speakNow(t);face.set('neutral')}
async function hfLoop(){if(hfRun)return;hfRun=true;
 while(hf){if(busy||sheetOpen()||document.hidden){await sleep(600);continue}
  try{const t=await Voice.listen(lang);if(t&&!busy)await say(t,true)}
  catch(e){if(/denied|not available|not supported/i.test(e.message)){toast('⚠ '+e.message);hf=false;break}await sleep(900)}
  await sleep(250)}
 hfRun=false}
function onVision(p,t,name){const now=Date.now();
 if(p){face.gaze(p[0]*.9,p[1]*.7);P.last=now;
  if(!seen&&now-lastSeen>8000){seen=true;emo('surprised',{},900);setTimeout(()=>emo('happy',{},3500),900);if(name){Mem.set('name',name);proact('greet','The owner named '+name+' just appeared; greet them by name.')}}
  if(name)unk=0;else if(Vision.mode=='recog'&&++unk==6&&now-unkAt>600000){unkAt=now;proact('unknown','An unknown person is in front of the camera; say you do not know them and that they can say "remember my face, my name is ..." if they want you to remember them.')}
  lastSeen=now}
 else if(seen&&now-t>4000){seen=false;unk=0;face.gaze(0,0)}}
async function startCam(){camOn=true;const ok=await Vision.start($('#cam'),onVision);if(!ok)toast(lang=='bn'?'ক্যামেরার অনুমতি পাওয়া যায়নি':'Camera permission denied');return ok}
async function wake(){$('#wake').classList.add('off');emo('surprised',{},800);
 try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop())}catch(e){toast(lang=='bn'?'মাইক্রোফোন ছাড়া চলবে':'Continuing without microphone')}
 if(camOn)await startCam();await Mem.set('setup',1);hfLoop()}
(async()=>{await Mem.open();lang=(await Mem.get('lang'))||'bn';tts=!!(await Mem.get('tts'));camOn=(await Mem.get('camon'))!==false;hf=(await Mem.get('hf'))!==false;
 $('#lang').value=lang;$('#tts').checked=tts;$('#camon').checked=camOn;$('#hf').checked=hf;$('#api').value=(await Mem.get('api'))||'';$('#tok').value=(await Mem.get('tok'))||'';$('#gkey').value=(await Mem.get('gkey'))||'';
 const cv=$('#face');cv.width=360;cv.height=Math.round(360*innerHeight/innerWidth);face=new Face(cv);
 $('#emos').innerHTML='';Object.keys(EMO).forEach(k=>{const b=document.createElement('button');b.textContent=k;b.onclick=()=>{sheet(false);emo(k,{},4000)};$('#emos').append(b)});
 COLORS.forEach(c=>{const b=document.createElement('button');b.style.background=c;b.setAttribute('aria-label',c);b.onclick=()=>{sheet(false);emo(face.name||'neutral',{color:c},4000)};$('#cols').append(b)});
 document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>tab(b.dataset.go));$('#close').onclick=()=>sheet(false);
 $('#send').onclick=()=>{const v=$('#msg').value.trim();if(v){$('#msg').value='';say(v)}};$('#msg').onkeydown=e=>{if(e.key=='Enter')$('#send').click()};
 $('#stop').onclick=()=>{Voice.stop();face.set('neutral')};$('#mic').onclick=()=>{hf=!hf;Mem.set('hf',hf);if(hf)hfLoop();else Voice.stopListen();toast(hf?'Listening on':'Listening off')};
 $('#msave').onclick=async()=>{if($('#mk').value){await Mem.set($('#mk').value,$('#mv').value);showMem()}};
 $('#mclear').onclick=async()=>{if(confirm('Delete all memory?')){await Mem.clear();showMem()}};
 $('#ssave').onclick=async()=>{lang=$('#lang').value;tts=$('#tts').checked;const c=$('#camon').checked;await Mem.set('lang',lang);await Mem.set('tts',tts);await Mem.set('camon',c);hf=$('#hf').checked;await Mem.set('hf',hf);if(hf)hfLoop();await Mem.set('api',$('#api').value.trim());await Mem.set('tok',$('#tok').value.trim());await Mem.set('gkey',$('#gkey').value.trim());toast('Saved, key length '+$('#gkey').value.trim().length);
  if(c&&!Vision.on)startCam();if(!c){Vision.stop();camOn=false}camOn=c;add('✓ Saved')};
 // Gestures: tap=happy, double-tap=excited, stroke=shy, long-press=listen, swipe up from bottom edge=menu
 let sx,sy,st,lp,long,lastTap=0,path=0,px,py;
 cv.onpointerdown=e=>{sx=px=e.clientX;sy=py=e.clientY;st=Date.now();long=false;path=0;P.last=Date.now();if(face.name=='sleep'||face.tgt.o<.1)emo('surprised',{},800);lp=setTimeout(()=>{if(path<30){long=true;hf=!hf;Mem.set('hf',hf);if(hf)hfLoop();else Voice.stopListen();toast(hf?(lang=='bn'?'শুনছি (হ্যান্ডস-ফ্রি চালু)':'Listening on'):(lang=='bn'?'শোনা বন্ধ':'Listening off'))}},650)};
 cv.onpointermove=e=>{if(!st)return;path+=Math.hypot(e.clientX-px,e.clientY-py);px=e.clientX;py=e.clientY;if(path>80&&path<400&&!long)face.set('shy')};
 cv.onpointerup=e=>{clearTimeout(lp);const dy=e.clientY-sy,d=Math.hypot(e.clientX-sx,dy);st=0;
  if(long)return;if(sy>innerHeight*.78&&dy<-60){sheet(true);return}
  if(d>60&&path>=400){emo('surprised',{},1500)}else if(path>=80){emo('shy',{},2500)}
  else if(Date.now()-lastTap<300)emo('excited',{},2500);else emo('happy',{},2000);lastTap=Date.now()};
 setInterval(()=>{if($('#sheet').classList.contains('on'))return;const idle=Date.now()-P.last;
  if(idle>180000){face.set('sleep');return}if(idle>90000){face.set('sleepy');return}if(idle>60000){face.set('sad');return}
  if(Math.random()<.5){const l=[['curious'],['happy'],['neutral'],['excited']];emo(P.pick(l)[0],{color:P.pick(COLORS)},2200)}
  if(!seen)face.gaze((Math.random()-.5)*1.6,(Math.random()-.5)*1.2)},7000);
 if(await Mem.get('setup'))$('#wake').classList.add('off'),camOn&&startCam(),hfLoop();
 $('#wake').onclick=wake;
 setInterval(()=>{const now=Date.now();if(!hf||busy||sheetOpen()||now<nextPro)return;nextPro=now+45000+Math.random()*75000;if(seen||now-P.last<300000)proact('idle','You have been quiet for a while; start a friendly conversation or ask a question.')},5000);
 $('#gpaste').onclick=async()=>{try{const C=window.Capacitor&&Capacitor.Plugins.Clipboard;const t=C?(await C.read()).value:await navigator.clipboard.readText();if(t){$('#gkey').value=t.trim();toast('Pasted ('+t.trim().length+' chars). Now press Save')}else toast('Clipboard is empty')}catch(e){toast('Paste failed: '+e.message)}};
 let ls=0,sk=0;addEventListener('devicemotion',e=>{const g=e.accelerationIncludingGravity;if(!g)return;if(Math.hypot(g.x,g.y,g.z)>30&&Date.now()-ls>1500){sk=Date.now()-ls>10000?1:sk+1;ls=Date.now();P.last=Date.now();Voice.stop();const cry=sk>2;face.set(cry?'cry':'pain');Voice.speak(cry?(lang=='bn'?'উঁউঁ… আর মেরো না, আমি কাঁদছি':'Waaah… stop, I\'m crying'):(lang=='bn'?'আউচ! ব্যথা লাগছে!':'Ouch! That hurts!'),lang,face);setTimeout(()=>face.set(cry?'sad':'neutral'),cry?6000:3500)}});
})();
