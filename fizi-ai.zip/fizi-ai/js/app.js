const $=s=>document.querySelector(s);let face,lang='bn',tts=false,camOn=true,seen=false,lastSeen=0;
const toast=t=>{const e=$('#toast');e.textContent=t;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),3500)};
const add=(t,u)=>{const d=document.createElement('div');d.className='m'+(u?' u':'');d.textContent=t;$('#log').append(d);d.scrollIntoView()};
const tab=n=>{document.querySelectorAll('#sheet section').forEach(s=>s.classList.toggle('on',s.id==n));if(n=='memory')showMem()};
const sheet=o=>{$('#sheet').classList.toggle('on',o);if(o)tab('chat')};
async function showMem(){const a=await Mem.all();$('#mem').innerHTML='';for(const k in a){if(['hist','api','tok','gkey','setup','lang','tts','camon'].includes(k))continue;const d=document.createElement('div');d.className='mi';d.textContent=k+': '+a[k];const b=document.createElement('button');b.textContent='✕';b.onclick=async()=>{await Mem.del(k);showMem()};d.append(b);$('#mem').append(d)}}
const emo=(n,o,ms=3000)=>{face.set(n,o);clearTimeout(emo.t);emo.t=setTimeout(()=>face.set('neutral'),ms)};
async function say(text,speak){P.last=Date.now();add(text,1);const r=await P.ask(text,lang,face);add(r);if(tts||speak){await Voice.speak(r,lang,face);if(speak&&Voice.loop)listen()}}
async function listen(){Voice.loop=true;face.set('curious');toast(lang=='bn'?'শুনছি…':'Listening…');
 try{const t=await Voice.listen(lang);if(t){say(t,true)}else{Voice.loop=false;face.set('neutral')}}
 catch(e){Voice.loop=false;face.set('neutral');if(!/no match|no speech|didn/i.test(e.message))toast('⚠ '+e.message)}}
function onVision(p,t){const now=Date.now();
 if(p){face.gaze(p[0]*.9,p[1]*.7);P.last=now;if(!seen&&now-lastSeen>8000){seen=true;emo('surprised',{},900);setTimeout(()=>emo('happy',{},3500),900);if(Vision.mode=='face'){toast(lang=='bn'?'তোমাকে দেখতে পাচ্ছি!':'I can see you!')}}lastSeen=now}
 else if(seen&&now-t>4000){seen=false;face.gaze(0,0)}}
async function startCam(){camOn=true;const ok=await Vision.start($('#cam'),onVision);if(!ok)toast(lang=='bn'?'ক্যামেরার অনুমতি পাওয়া যায়নি':'Camera permission denied');return ok}
async function wake(){$('#wake').classList.add('off');emo('surprised',{},800);
 try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop())}catch(e){toast(lang=='bn'?'মাইক্রোফোন ছাড়া চলবে':'Continuing without microphone')}
 if(camOn)await startCam();await Mem.set('setup',1)}
(async()=>{await Mem.open();lang=(await Mem.get('lang'))||'bn';tts=!!(await Mem.get('tts'));camOn=(await Mem.get('camon'))!==false;
 $('#lang').value=lang;$('#tts').checked=tts;$('#camon').checked=camOn;$('#api').value=(await Mem.get('api'))||'';$('#tok').value=(await Mem.get('tok'))||'';$('#gkey').value=(await Mem.get('gkey'))||'';
 const cv=$('#face');cv.width=360;cv.height=Math.round(360*innerHeight/innerWidth);face=new Face(cv);
 $('#emos').innerHTML='';Object.keys(EMO).forEach(k=>{const b=document.createElement('button');b.textContent=k;b.onclick=()=>{sheet(false);emo(k,{},4000)};$('#emos').append(b)});
 COLORS.forEach(c=>{const b=document.createElement('button');b.style.background=c;b.setAttribute('aria-label',c);b.onclick=()=>{sheet(false);emo(face.name||'neutral',{color:c},4000)};$('#cols').append(b)});
 document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>tab(b.dataset.go));$('#close').onclick=()=>sheet(false);
 $('#send').onclick=()=>{const v=$('#msg').value.trim();if(v){$('#msg').value='';say(v)}};$('#msg').onkeydown=e=>{if(e.key=='Enter')$('#send').click()};
 $('#stop').onclick=()=>{Voice.stop();face.set('neutral')};$('#mic').onclick=()=>listen();
 $('#msave').onclick=async()=>{if($('#mk').value){await Mem.set($('#mk').value,$('#mv').value);showMem()}};
 $('#mclear').onclick=async()=>{if(confirm('Delete all memory?')){await Mem.clear();showMem()}};
 $('#ssave').onclick=async()=>{lang=$('#lang').value;tts=$('#tts').checked;const c=$('#camon').checked;await Mem.set('lang',lang);await Mem.set('tts',tts);await Mem.set('camon',c);await Mem.set('api',$('#api').value.trim());await Mem.set('tok',$('#tok').value.trim());await Mem.set('gkey',$('#gkey').value.trim());
  if(c&&!Vision.on)startCam();if(!c){Vision.stop();camOn=false}camOn=c;add('✓ Saved')};
 // Gestures: tap=happy, double-tap=excited, stroke=shy, long-press=listen, swipe up from bottom edge=menu
 let sx,sy,st,lp,long,lastTap=0,path=0,px,py;
 cv.onpointerdown=e=>{sx=px=e.clientX;sy=py=e.clientY;st=Date.now();long=false;path=0;P.last=Date.now();if(face.name=='sleep'||face.tgt.o<.1)emo('surprised',{},800);lp=setTimeout(()=>{if(path<30){long=true;listen()}},650)};
 cv.onpointermove=e=>{if(!st)return;path+=Math.hypot(e.clientX-px,e.clientY-py);px=e.clientX;py=e.clientY;if(path>80&&path<400&&!long)face.set('shy')};
 cv.onpointerup=e=>{clearTimeout(lp);const dy=e.clientY-sy,d=Math.hypot(e.clientX-sx,dy);st=0;
  if(long)return;if(sy>innerHeight*.78&&dy<-60){sheet(true);return}
  if(d>60&&path>=400){emo('surprised',{},1500)}else if(path>=80){emo('shy',{},2500)}
  else if(Date.now()-lastTap<300)emo('excited',{},2500);else emo('happy',{},2000);lastTap=Date.now()};
 setInterval(()=>{if($('#sheet').classList.contains('on'))return;const idle=Date.now()-P.last;
  if(idle>180000){face.set('sleep');return}if(idle>90000){face.set('sleepy');return}if(idle>60000){face.set('sad');return}
  if(Math.random()<.5){const l=[['curious'],['happy'],['neutral'],['excited']];emo(P.pick(l)[0],{color:P.pick(COLORS)},2200)}
  if(!seen)face.gaze((Math.random()-.5)*1.6,(Math.random()-.5)*1.2)},7000);
 if(await Mem.get('setup'))$('#wake').classList.add('off'),camOn&&startCam();
 $('#wake').onclick=wake;
 let ls=0,sk=0;addEventListener('devicemotion',e=>{const g=e.accelerationIncludingGravity;if(!g)return;if(Math.hypot(g.x,g.y,g.z)>30&&Date.now()-ls>1500){sk=Date.now()-ls>10000?1:sk+1;ls=Date.now();P.last=Date.now();Voice.stop();const cry=sk>2;face.set(cry?'cry':'pain');Voice.speak(cry?(lang=='bn'?'উঁউঁ… আর মেরো না, আমি কাঁদছি':'Waaah… stop, I\'m crying'):(lang=='bn'?'আউচ! ব্যথা লাগছে!':'Ouch! That hurts!'),lang,face);setTimeout(()=>face.set(cry?'sad':'neutral'),cry?6000:3500)}});
})();
