const EMO={neutral:{o:1,lt:0,lb:0,c:'#ffffff',m:[.05,0,40,0]},happy:{o:.95,lt:0,lb:.5,c:'#ffffff',m:[.9,0,55,0]},
sad:{o:.85,lt:-.8,lb:0,c:'#cfe0ff',tear:1,m:[-.8,0,40,0]},angry:{o:.85,lt:.85,lb:0,c:'#ffd6d6',m:[-.4,0,45,8]},
sleepy:{o:.3,lt:.2,lb:0,c:'#e6dcff',m:[0,.1,30,0]},curious:{o:1.1,lt:0,lb:0,c:'#fff6c9',asym:1,m:[.1,0,35,10]},
surprised:{o:1.25,lt:0,lb:0,c:'#ffffff',w:.8,m:[0,.8,18,0]},excited:{o:1.1,lt:0,lb:.35,c:'#ffe6fb',shake:1,m:[.9,.6,55,0]},
shy:{o:.65,lt:-.3,lb:.25,c:'#ffd9ea',look:[-.6,.5],m:[.5,0,25,0]},cry:{o:.6,lt:-.9,lb:0,c:'#cfe0ff',tear:2,shake:1,m:[-.9,.5,40,0]},
laugh:{o:.35,lt:0,lb:.7,c:'#ffffff',shake:1,m:[.9,.85,60,0]},pain:{o:.22,lt:-.6,lb:0,w:1.1,c:'#ffe0e0',tear:2,shake:1,m:[-.7,.7,35,0]},
sleep:{o:.03,lt:0,lb:0,c:'#e6dcff',m:[.1,0,30,0]}};
const COLORS=['#ffffff','#bff7ff','#e0ccff','#c8ffe6','#ffe9a8','#ffc4e8'];
class Face{
 constructor(cv){this.cv=cv;this.x=cv.getContext('2d');this.cur={...EMO.neutral,w:1,m:[...EMO.neutral.m]};this.tgt={...this.cur};this.look=[0,0];this.lt=[0,0];this.blink=0;this.nb=performance.now()+2500;this.tear=0;this.shake=0;this.t=0;this.talking=false;this.name='neutral';requestAnimationFrame(()=>this.loop());}
 set(name,opt={}){const e=EMO[name]||EMO.neutral;this.name=name;this.tgt={w:1,lb:0,lt:0,asym:0,...e,c:opt.color||e.c};this.tear=e.tear||0;this.shake=e.shake||0;if(e.look)this.lt=e.look;}
 gaze(x,y){this.lt=[x,y]}talk(on){this.talking=on}
 loop(){const n=performance.now(),c=this.cur,g=this.tgt;this.t=n/1000;
  for(const p of['o','lt','lb','w'])c[p]+=(g[p]-c[p])*.18;for(let i=0;i<4;i++)c.m[i]+=(g.m[i]-c.m[i])*.18;c.c=g.c;c.asym=g.asym;
  if(n>(this.ns||0)){this.ns=n+700+Math.random()*2200;this.j=[(Math.random()-.5)*.25,(Math.random()-.5)*.2]}const j=this.j||[0,0];
  this.look[0]+=(this.lt[0]+j[0]-this.look[0])*.18;this.look[1]+=(this.lt[1]+j[1]-this.look[1])*.18;
  if(n>this.nb){this.blink=1;this.nb=Math.random()<.2?n+250:n+2000+Math.random()*3500}this.blink=Math.max(0,this.blink-.12);
  this.draw();requestAnimationFrame(()=>this.loop());}
 draw(){const x=this.x,W=this.cv.width,H=this.cv.height,c=this.cur,t=this.t;x.clearRect(0,0,W,H);
  const sh=this.shake?Math.sin(t*40)*3:0,br=1+Math.sin(t*1.6)*.02,bob=Math.sin(t*2)*4,bl=1-Math.sin(Math.min(1,this.blink)*Math.PI);
  x.save();x.translate(W/2+sh,H/2+bob*(this.dance?3:1));x.rotate(this.dance?Math.sin(t*4)*.09:0);x.scale(1.15*br,1.15*br);x.translate(-W/2,-H/2);
  [-1,1].forEach(s=>{const rx=60*c.w,ry=72*c.o*bl*(c.asym&&s>0?.75:1),cx=W/2+s*85,cy=H/2-40;
   if(ry<4){x.strokeStyle=c.c;x.lineWidth=6;x.lineCap='round';x.beginPath();x.moveTo(cx-rx*.8,cy);x.quadraticCurveTo(cx,cy+10,cx+rx*.8,cy);x.stroke();return}
   x.save();x.beginPath();x.ellipse(cx,cy,rx,ry,0,0,7);x.clip();x.fillStyle=c.c;x.fillRect(cx-rx-2,cy-ry-2,rx*2+4,ry*2+4);
   const pr=Math.min(27,ry*.5),px=cx+this.look[0]*(rx-pr-4),py=cy+this.look[1]*(ry-pr)+ry*.12;
   x.fillStyle='#000';x.beginPath();x.arc(px,py,pr,0,7);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(px-pr*.3,py-pr*.35,pr*.22,0,7);x.fill();
   x.fillStyle='#000';const cut=ry*Math.abs(c.lt)*1.1,inn=c.lt>0?cut:cut*.1,out=c.lt>0?cut*.1:cut,yi=cy-ry+inn,yo=cy-ry+out,xi=cx-s*rx,xo=cx+s*rx;
   x.beginPath();x.moveTo(cx-rx-4,cy-ry-4);x.lineTo(cx+rx+4,cy-ry-4);x.lineTo(s<0?cx+rx+4:cx-rx-4,s<0?yi:yi);x.lineTo(s<0?cx-rx-4:cx+rx+4,yo);x.closePath();x.fill();
   if(c.lb>.02){x.beginPath();x.ellipse(cx,cy+ry*(1.15-c.lb*.6),rx*1.3,ry*.9,0,0,7);x.fill()}
   x.restore();
   if(this.tear){x.fillStyle='#8fd3ff';x.beginPath();x.arc(cx+s*12,cy+ry+((t*70*this.tear+s*20)%60),7,0,7);x.fill()}});
  // mouth (lip-syncs while speaking)
  const m=c.m,amp=this.talking?.2+.55*Math.abs(Math.sin(t*14))*(.6+.4*Math.sin(t*5.3)):0,mo=Math.max(m[1],amp),mw=m[2]*(this.talking?1+Math.sin(t*9)*.08:1),cv=m[0],my=H/2+105,L=W/2-mw,R=W/2+mw;
  x.strokeStyle='#fff';x.lineWidth=6;x.lineCap='round';x.lineJoin='round';x.beginPath();
  if(mo<.06){x.moveTo(L,my-cv*14+m[3]);x.quadraticCurveTo(W/2,my+cv*28,R,my-cv*14-m[3]);x.stroke()}
  else{x.moveTo(L,my-cv*10);x.quadraticCurveTo(W/2,my+cv*14-mo*6,R,my-cv*10);x.quadraticCurveTo(W/2,my+cv*14+mo*80,L,my-cv*10);x.fillStyle='#14080c';x.fill();x.stroke()}
  x.restore();}}
