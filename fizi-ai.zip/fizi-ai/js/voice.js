// Uses native Android speech (Capacitor plugins) when available; falls back to Web Speech.
const CP=()=>(window.Capacitor&&window.Capacitor.Plugins)||{};
const Voice={loop:false,
 async listen(lang){const L=lang=='bn'?'bn-BD':'en-US',SRp=CP().SpeechRecognition;
  if(SRp){const a=await SRp.available();if(!a.available)throw new Error('Speech recognition not available on this phone (install Google app).');
   const p=await SRp.requestPermissions();if(p.speechRecognition&&p.speechRecognition!=='granted')throw new Error('Microphone permission denied.');
   const r=await SRp.start({language:L,maxResults:1,partialResults:false,popup:false});return r.matches&&r.matches[0]||''}
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)throw new Error('Speech recognition is not supported here.');
  return new Promise((res,rej)=>{const r=new SR();r.lang=L;r.onresult=e=>res(e.results[0][0].transcript);r.onerror=e=>rej(new Error(e.error));r.onend=()=>res('');r.start()})},
 async speak(text,lang,face,o={}){const L=lang=='bn'?'bn-BD':'en-US',T=CP().TextToSpeech;face&&face.talk(true);
  try{if(T){await T.speak({text,lang:L,rate:o.rate||1,pitch:o.pitch||1.15,volume:1,category:'ambient'})}
   else if('speechSynthesis' in window){speechSynthesis.cancel();await new Promise(r=>{const u=new SpeechSynthesisUtterance(text);u.lang=L;u.onend=r;u.onerror=r;speechSynthesis.speak(u)})}}
  catch(e){}finally{face&&face.talk(false)}},
 stop(){this.loop=false;const p=CP();try{p.TextToSpeech&&p.TextToSpeech.stop()}catch(e){}try{p.SpeechRecognition&&p.SpeechRecognition.stop()}catch(e){}if('speechSynthesis' in window)speechSynthesis.cancel()}};

Voice.stopListen=()=>{try{CP().SpeechRecognition&&CP().SpeechRecognition.stop()}catch(e){}};
