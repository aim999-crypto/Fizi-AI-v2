# FIZI AI (core build)
## Working now
Animated canvas face (11 emotions x 6 colors x gaze/timing combos), blinking, gaze tracking, touch reactions, bilingual chat (offline scripted replies, NOT real AI), optional backend AI via your own URL, voice input (Web Speech, if the WebView supports it) and TTS, IndexedDB memory with view/edit/delete, autonomous moods.
## Not built yet
Camera/vision, music/dance, mini-games, timer/alarm/weather, emotion gallery, splash, custom icon.
## Run
`npx serve .` (any static server) or open index.html.
## APK (needs a computer or Termux with Node + Android SDK)
```
npm install && npm run build
npx cap add android && npx cap sync
npx cap open android   # Android Studio: Build > Build APK
```
Add `<uses-permission android:name="android.permission.RECORD_AUDIO"/>` (and CAMERA later) to android/app/src/main/AndroidManifest.xml.
## Secure AI backend
Put the API key in a server env var (e.g. Cloudflare Worker). Accept POST {message,lang,history,persona}, return {reply}. Paste its URL in Settings.
## Test checklist
Face blinks; each emotion button works; tap/double-tap/long-press/swipe react; chat "hello", "my name is X", "joke"; Memory shows name; mic works or shows an error; Stop silences voice; ignore 60s -> sad.

## v0.2
Full-screen face with no visible icons. Swipe up from the bottom edge for Chat / Gallery / Memory / Settings. Long-press the face to speak. Camera runs hidden: eyes follow your face (FaceDetector if the WebView supports it, otherwise motion tracking). Android manifest needs CAMERA and RECORD_AUDIO.
Not done: object recognition, naming faces (need a bundled ML model).

## Real AI backend (free)
1. Get a free key at aistudio.google.com (Get API key).
2. dash.cloudflare.com > Workers & Pages > Create > Hello World > Deploy, then Edit code, paste backend/worker.js, Deploy.
3. Worker > Settings > Variables and Secrets: add secret GEMINI_API_KEY. Optional secret APP_TOKEN (any password).
4. Paste the worker URL (and token) into FIZI Settings > Backend URL.
